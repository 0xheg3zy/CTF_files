#!/bin/bash

bash script.sh &

apache2-foreground
