<?php
 ini_set("error_reporting", 0);
 ini_set("short_open_tag", "Off");

 if(isset($_GET['source'])) {
     highlight_file(__FILE__);
 }

 include "flag.php";

 $input = $_GET['input'];

 if(preg_match('/[^\x21-\x7e]/', $input)) {
     die("Illegal characters detected!");
 }

$filter = array("<?php", "<? ", "?>", "echo", "var_dump", "var_export", "print_r", "FLAG");
$filter = array("<?php", "<? ", "?>","*", "/", "var_dump", "var_export", "print_r", "FLAG");
foreach($filter as &$keyword) {
    if(str_contains($input, $keyword)) {
        die("PHP code detected!\n");
    }
} 
echo eval("?>" . $input);

echo "\n";

?>